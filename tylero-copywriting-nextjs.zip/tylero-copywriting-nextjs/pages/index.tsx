import { motion } from 'framer-motion';
import { Phone, Instagram } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-900 p-6 space-y-16">
      <section className="text-center max-w-3xl mx-auto space-y-6">
        <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-4xl font-bold">
          Tyler O Copywriting Services
        </motion.h1>
        <p className="text-lg text-gray-600">
          Professional copywriting for small businesses, startups, and tech companies.
        </p>
        <button className="text-white bg-black px-4 py-2 rounded hover:bg-gray-800">Let’s Work Together</button>
      </section>

      <section className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border p-4 rounded-lg shadow">
            <h3 className="text-xl font-medium mb-2">Email Marketing</h3>
            <p>Engaging, results-driven emails that convert and nurture your audience.</p>
          </div>
          <div className="border p-4 rounded-lg shadow">
            <h3 className="text-xl font-medium mb-2">Product Descriptions</h3>
            <p>Clear, compelling product copy that highlights benefits and drives sales.</p>
          </div>
          <div className="border p-4 rounded-lg shadow">
            <h3 className="text-xl font-medium mb-2">Blog Posts</h3>
            <p>Informative and SEO-friendly blog content tailored to your brand voice.</p>
          </div>
        </div>
      </section>

      <section className="max-w-3xl mx-auto space-y-4">
        <h2 className="text-2xl font-semibold">About Tyler</h2>
        <p>
          I'm Tyler, a copywriter dedicated to helping small businesses and startups find their voice. I specialize in clear, strategic writing that connects with your audience and gets results.
        </p>
      </section>

      <section className="max-w-3xl mx-auto space-y-4">
        <h2 className="text-2xl font-semibold">More About Me</h2>
        <p>
          I graduated from Florida State University in 2020 with a degree in Criminology and a minor in Marketing. Before that, I played college basketball at Wisconsin Lutheran College from 2015–2017. I’ve always been passionate about helping others achieve their goals, which is what drew me to copywriting—I want to help businesses grow by making their messages heard.
        </p>
        <p>
          Since graduating, I’ve worked in high-performing sales roles, generating over $5 million in revenue for the companies I’ve represented. I even got my start knocking on doors in college as a door-to-door salesman. That experience gave me a unique understanding of people and what makes a message stick.
        </p>
        <p>
          When I’m not writing, you’ll probably find me working out, shooting hoops, or hanging with friends, family, and my dog.
        </p>
      </section>

      <section className="max-w-3xl mx-auto space-y-4">
        <h2 className="text-2xl font-semibold">Contact</h2>
        <p>Let’s talk about how we can make your brand sound its best.</p>
        <div className="flex items-center space-x-4">
          <Phone className="text-gray-600" /> <span>480-822-8275</span>
        </div>
        <div className="flex items-center space-x-4">
          <Instagram className="text-gray-600" /> <span>@tylerocopywriter</span>
        </div>
      </section>
    </div>
  );
}